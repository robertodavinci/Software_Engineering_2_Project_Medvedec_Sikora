package com.example.clup.Services;

import com.example.clup.Entities.Store;
import com.example.clup.Entities.Timeslot;
import com.example.clup.OnGetTimeslotListener;

public interface QueueService {
    //public void getFreeTimeslot(Store store, OnGetTimeslotListener onGetTimeslotListener);
}
