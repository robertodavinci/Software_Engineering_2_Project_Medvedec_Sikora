package com.example.clup.Entities;

public enum UserType {
    STORE_MANAGER;
}
