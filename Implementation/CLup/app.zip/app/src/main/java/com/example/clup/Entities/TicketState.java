package com.example.clup.Entities;

public enum TicketState {
    WAITING,
    ACTIVE;
    //IN_STORE,
    //EXPIRED;
}
