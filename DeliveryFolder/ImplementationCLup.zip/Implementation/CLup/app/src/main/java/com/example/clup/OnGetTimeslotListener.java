package com.example.clup;

import com.example.clup.Entities.Timeslot;

public interface OnGetTimeslotListener {
    public void onSuccess(Timeslot timeslot);
}
