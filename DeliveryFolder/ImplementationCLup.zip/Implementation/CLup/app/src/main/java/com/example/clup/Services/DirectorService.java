package com.example.clup.Services;

public interface DirectorService {

}
