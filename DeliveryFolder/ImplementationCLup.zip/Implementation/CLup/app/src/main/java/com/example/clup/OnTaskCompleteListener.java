package com.example.clup;


public interface OnTaskCompleteListener {
    void onSuccess();
    void onFailure(int errCode);
}
