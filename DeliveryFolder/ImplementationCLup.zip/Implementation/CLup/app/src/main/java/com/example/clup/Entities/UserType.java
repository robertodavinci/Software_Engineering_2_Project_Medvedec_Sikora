package com.example.clup.Entities;

// UserType has only one value in this version, since only app users with an account are store managers
public enum UserType {
    STORE_MANAGER;
}
